<div class="sidebar">
    <h2><?php _e('Categories'); ?></h2>
    <ul>
        <?php wp_list_categories('sort_column=name&optioncount=1&hierarchial=0'); ?>
    </ul>
    <h2><?php _e('Archive'); ?></h2>
    <ul>
        <?php wp_get_archives('type=monthly'); ?>
    </ul>
</div>